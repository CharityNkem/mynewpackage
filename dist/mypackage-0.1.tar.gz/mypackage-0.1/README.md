# mynewpackage
This library was used to learn how to publish and install my own package